#ifndef _TIM_DRIVER_H_
#define _TIM_DRIVER_H_


#include "stm32f10x.h" 





/***********************************************************************/
void TIM_InitConfig(void);


#endif
