#include "data_pack.h"
#include "usart_driver.h"
#include "ST_string.h"

uint8_t DevSeqByte = 0;

uint8_t Pack_IntegerData(u8 buff[],uint16_t lenth,uint8_t cmd,uint8_t seq,
			uint16_t w,uint16_t x,uint16_t y,uint16_t z)
{
	u8 array[16] = {0};
	u8 data_l = 0,data_h = 0;
	
	u8 i = 0;
	
	//start flag
	array[0] = 0xff;
	array[1] = 0xff;

	//lenth
	data_l = lenth&0xff;
	data_h = (lenth>>8)&0xff;
	array[2] = data_h;
	array[3] = data_l;

	//cmd
	array[4] = cmd;

	//seq
	array[5] = seq;
	//Data type
	array[6] = 0x00;

	
	if(cmd == DEV_QUATERNION)
	{
		//W
		data_l = w&0xff;
		data_h = (w>>8)&0xff;
		array[7] = data_h;
		array[8] = data_l;
		//X
		data_l = x&0xff;
		data_h = (x>>8)&0xff;
		array[9] = data_h;
		array[10] = data_l;
		//Y
		data_l = y&0xff;
		data_h = (y>>8)&0xff;
		array[11] = data_h;
		array[12] = data_l;
		//Z
		data_l = z&0xff;
		data_h = (z>>8)&0xff;
		array[13] = data_h;
		array[14] = data_l;

		//CRC
		data_h = array[2];
		for(i = 3;i < 15;i++)
		{
			data_h = data_h^array[i];
		}

		array[15] = data_h;

		for(i = 0;i < 16;i++)
		{
			buff[i] = array[i];
			printf("%c",buff[i]);
		}

		return 16;
	}
	else
	{
		//X
		data_l = x&0xff;
		data_h = (x>>8)&0xff;
		array[7] = data_h;
		array[8] = data_l;
		//Y
		data_l = y&0xff;
		data_h = (y>>8)&0xff;
		array[9] = data_h;
		array[10] = data_l;
		//Z
		data_l = z&0xff;
		data_h = (z>>8)&0xff;
		array[11] = data_h;
		array[12] = data_l;

		//CRC
		data_h = array[2];
		for(i = 3;i < 13;i++)
		{
			data_h = data_h^array[i];
		}

		array[13] = data_h;

		for(i = 0;i < 14;i++)
		{
			buff[i] = array[i];
			printf("%c",buff[i]);
		}

		return 14;
	}

//	return 0;
}

uint8_t Pack_IntegerData_Temp(u8 buff[],uint16_t lenth,uint8_t seq,float temp)
{
	u8 array[16] = {0};
	u8 data_l = 0,data_h = 0;
	u16 i = 0;
	
	//start flag
	array[0] = 0xff;
	array[1] = 0xff;

	//lenth
	data_l = lenth&0xff;
	data_h = (lenth>>8)&0xff;
	array[2] = data_h;
	array[3] = data_l;

	//cmd
	array[4] = DEV_TEMP;

	//seq
	array[5] = seq;
	//Data type
	array[6] = 0x00;

	
	//Z
	data_h = (uint8_t)temp;	//����
	data_l= (uint8_t)((temp-data_h)*100);	//С��
	array[7] = data_h;
	array[8] = data_l;

	//CRC
	data_h = array[2];
	for(i = 3;i < 11;i++)
	{
		data_h = data_h^array[i];
	}

	array[15] = data_h;

	for(i = 0;i < 12;i++)
	{
		buff[i] = array[i];
	}

	return 16;
}


uint8_t Untie_DataPack(uint8_t buff[])
{
	uint16_t lenth = 0;
	uint16_t i = 0;
	uint8_t crc_data = 0;
	//Protocol Strings�ַ���Э��
	char sidReq[] = "board_get_sid()";   //SID RequestSidҪ��
	char sidResp[] = "board_sid(A0)";    //SID ResponseSID��Ӧ
	char startStr[] = "bsx_get_data(-1,4)";  //Start Streaming��ʼ��
	char stopStr[] = "bsx_get_data(0,4)";  //Stop Streaming������
	
	if( st_strcmp((int8_t *)USART3_BUF,(int8_t *)sidReq) == 0)
	{
		Clear_USART_Buff(USART3_BUF);
		printf("%s",sidResp);
		streamData = 1;
		
	}
	else if(st_strcmp((int8_t *)USART3_BUF,(int8_t *)stopStr) == 0)
	{
		Clear_USART_Buff(USART3_BUF);
		streamData = 0;
	}
	else if(st_strcmp((int8_t *)USART3_BUF,(int8_t *)startStr) == 0)
	{			
		Clear_USART_Buff(USART3_BUF);
		streamData = 1;
	}
	return 0;
}



