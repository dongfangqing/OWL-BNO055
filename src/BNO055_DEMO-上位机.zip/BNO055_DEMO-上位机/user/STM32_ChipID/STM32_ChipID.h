#ifndef _STM32_CHIPID_H_
#define _STM32_CHIPID_H_


#include "stm32f10x.h"




u8 Get_ChipID(u32* CPU_ID);



u32 WIFI_UserNum_Val(u32* CPU_ID);


#endif
