/*********************************SW-IOT32*********************************                                      
 
	                         \\\|///
                       \\  - -  //
                        (  @ @  )
+---------------------oOOo-(_)-oOOo-------------------------+
|                                                           |
|                             Oooo                          |
+-----------------------oooO--(   )-------------------------+
                       (   )   ) /
                        \ (   (_/
                         \_)           
***************************************************************************/

#include "stm32f10x.h" 
#include "sys_rcc.h"
#include "SysTick.h"
#include "led_driver.h" 
#include "usart_driver.h" 
#include "bno055.h"
#include "i2c_gpio.h"
#include "bno055_sonser.h"
#include "i2croutines.h"
#include "i2cdev.h"
#include "Run_task.h"
#include "HF_LPT200.h"


extern s32 bno055_data_readout_template(void);
extern uint8_t BNO055_CheckOk(void);
extern s8 BNO055_I2C_bus_write(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);
extern s8 BNO055_I2C_bus_read(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);
#if 1

extern void WIFI_HF_LPT200_Init(void);
extern struct bno055_t bno055;
int main(void)
{
//	u8 chip_id = 0;
	
	RCC_Configuration();
	SysTick_init(72);
	USART_InitConfig();
	
//	Usart3_Sendstr("Hello USART3!!\r\n");
//	
//	while(1)
//	{
////		delay_ms(1000);
//	}
	printf("hello main!!\r\n");
	LED_GPIO_Config();
	i2cdevInit(I2C1);
	
	PWM_Channel1_Out(10);
	PWM_Channel2_Out(130);
	PWM_Channel3_Out(10);
	
	WIFI_HF_LPT200_RestoreFactory();
	
	WIFI_HF_LPT200_Init();
	
//	WIFI_HF_LPT200_Set_TCPServer_Mode();
//	WIFI_HF_LPT200_Set_TCPClient_Mode("8899,10.10.100.254");
	
	WIFI_HF_LPT200_Leave_ATMode();
	
	delay_ms(1000);
	
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(1000);

	
	if(WIFI_HF_LPT200_Check_Start())
		printf("Wifi Startup Filed!!!\r\n");
	else
		printf("Wifi Startup OK!!!\r\n");
	
	printf("hello ccc\r\n");

	Run_Start();



	
#if 0	
	printf("+++++++++++++\r\n");
	bno055_data_readout_template();
//	BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
//					BNO055_CHIP_ID_REG, &chip_id,BNO055_GEN_READ_WRITE_LENGTH);
	
	bno055_read_chip_id(&chip_id);
	
	printf("chip_id = 0x%x\r\n",chip_id);
	chip_id = 0;
	
	printf("==============\r\n");
	
	while(1)
	{
		delay_ms(2000);

		delay_ms(8000);
//		BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
//					BNO055_CHIP_ID_REG, &chip_id,BNO055_GEN_READ_WRITE_LENGTH);
		bno055_read_chip_id(&chip_id);
	
		printf("chip_id = 0x%x\r\n",chip_id);
		chip_id = 0;
	}
#endif
}

#else

void clear_buff(u8 buf[],u8 len)
{
	u8 i = 0;
	for(i = 0;i < len;i++)
	{
		buf[i] = 0;
	}
}

int main(void)
{
//	uint8_t e_buf[10] = {0};
//	uint8_t e_Rbuf[10] = {0};
//	uint8_t i = 0;
	/* variable used to read the accel x data */
	s16 accel_datax = BNO055_INIT_VALUE;
	 /* variable used to read the accel y data */
	s16 accel_datay = BNO055_INIT_VALUE;
	/* variable used to read the accel z data */
	s16 accel_dataz = BNO055_INIT_VALUE;
	/* variable used to read the mag x data */
	s16 mag_datax  = BNO055_INIT_VALUE;
	/* variable used to read the mag y data */
	s16 mag_datay  = BNO055_INIT_VALUE;
	/* variable used to read the mag z data */
	s16 mag_dataz  = BNO055_INIT_VALUE;
	/* variable used to read the gyro x data */
	s16 gyro_datax = BNO055_INIT_VALUE;
	/* variable used to read the gyro y data */
	s16 gyro_datay = BNO055_INIT_VALUE;
	 /* variable used to read the gyro z data */
	s16 gyro_dataz = BNO055_INIT_VALUE;
	s32 comres = BNO055_ERROR;

	unsigned char accel_calib_status = 0;
	unsigned char gyro_calib_status = 0;
	unsigned char mag_calib_status = 0;
	unsigned char sys_calib_status = 0;

	/* variable used to read the accel xyz data */
	struct bno055_accel_t accel_xyz;
	/* structure used to read the mag xyz data */
	struct bno055_mag_t mag_xyz;
	 /* structure used to read the gyro xyz data */
	struct bno055_gyro_t gyro_xyz;
	struct bno055_euler_t euler_hrp;
	/* structure used to read the quaternion wxyz data */
	struct bno055_quaternion_t quaternion_wxyz;
	/* structure used to read the linear accel xyz data */
	struct bno055_linear_accel_t linear_acce_xyz;
	/* structure used to read the gravity xyz data */
	struct bno055_gravity_t gravity_xyz;

	s16 w,  x,  y,  z;

	
	u8 chip_id = 0;
	u8 ret = 0;
	u8 operation_mode = 0;
	u8 power_mode_u8 = 0;
	u8 data[8] = {0};
	s8 temp_s8 = 0;
	
	RCC_Configuration();
	SysTick_init(72);
	USART1_Config();
//	SPI_InitConfig();
	printf("hello main!!\r\n");
	LED_GPIO_Config();
//	I2C_GPIOInitConfig();

	i2cdevInit(I2C1);
	printf("hello ccc\r\n");
	PWM_Channel1_Out(10);
	PWM_Channel2_Out(130);
	PWM_Channel3_Out(10);
//	printf("hello main!!\r\n");
	printf("hello ccc\r\n");
/*
	if(!BNO055_CheckOk())
	{
		while(1);
	}
	*/
	printf("+++++++++++++\r\n");
//	bno055_data_readout_template();

	bno055_Setup();
	printf("==============\r\n");
	
	bno055_get_operation_mode(&operation_mode);
	printf("operation_mode = %d\r\n",operation_mode);
	
	bno055_read_chip_id(&chip_id);
	
	printf("chip_id = %d\r\n",chip_id);
	
	
	ret = bno055_get_accel_calib_stat(&accel_calib_status);
	printf("ret1 = %d\r\n",ret);
	ret = bno055_get_mag_calib_stat(&mag_calib_status);
	printf("ret2 = %d\r\n",ret);
	ret = bno055_get_gyro_calib_stat(&gyro_calib_status);
	printf("ret3 = %d\r\n",ret);
	ret = bno055_get_sys_calib_stat(&sys_calib_status);
	printf("ret4 = %d\r\n",ret);
	
	printf("accel_calib_status = %d\r\n",accel_calib_status);
	printf("mag_calib_status = %d\r\n",mag_calib_status);
	printf("gyro_calib_status = %d\r\n",gyro_calib_status);
	printf("sys_calib_status = %d\r\n",sys_calib_status);

	bno055_get_operation_mode(&operation_mode);
	printf("operation_mode = %d\r\n",operation_mode);
	bno055_get_power_mode(&power_mode_u8);
	printf("power_mode_u8 = %d\r\n",power_mode_u8);
	BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
					BNO055_ACCEL_REV_ID_ADDR, &chip_id,BNO055_GEN_READ_WRITE_LENGTH);
	printf("Accel_id = 0x%x\r\n",chip_id);
	BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
					BNO055_MAG_REV_ID_ADDR, &chip_id,BNO055_GEN_READ_WRITE_LENGTH);
	printf("mag_id = 0x%x\r\n",chip_id);

	BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
					BNO055_GYRO_REV_ID_ADDR, &chip_id,BNO055_GEN_READ_WRITE_LENGTH);
	printf("gyro_id = 0x%x\r\n",chip_id);


	
	
/*	BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
				BNO055_ACCEL_DATA_X_LSB_VALUEX_REG,
				data, 2);*/
	printf("accel_x = 0x%x\r\n",(data[1]<<8)|data[0]);

	bno055_read_temp_data(&temp_s8);
	printf("temp_s8 = %d\r\n",temp_s8);
//	while(1);
	
	comres = 0;
	
	while(1)
	{
#if 0
//		comres += bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
		delay_ms(100);
		comres += bno055_read_accel_x(&accel_datax);
		delay_ms(100);
		comres += bno055_read_accel_y(&accel_datay);
		delay_ms(100);
		comres += bno055_read_accel_z(&accel_dataz);
		delay_ms(100);
		
//		printf("accel Data: comres = %d\r\n",comres);
		printf("accel_datax = %5d\r\n",accel_datax);
		printf("accel_datay = %5d\r\n",accel_datay);
		printf("accel_dataz = %5d\r\n",accel_dataz);
		printf(" \r\n");
		
		comres += bno055_read_mag_x(&mag_datax);
		delay_ms(100);
		comres += bno055_read_mag_y(&mag_datay);
		delay_ms(100);
		comres += bno055_read_mag_z(&mag_dataz);
		delay_ms(100);
//		printf("mag Data: comres = %d\r\n",comres);
		printf("mag_datax = %5d\r\n",mag_datax);
		printf("mag_datay = %5d\r\n",mag_datay);
		printf("mag_dataz = %5d\r\n",mag_dataz);
		printf(" \r\n");
		
		comres += bno055_read_gyro_x(&gyro_datax);
		delay_ms(100);
		comres += bno055_read_gyro_y(&gyro_datay);
		delay_ms(100);
		comres += bno055_read_gyro_z(&gyro_dataz);
//		printf("gyro Data: comres = %d\r\n",comres);
		printf("gyro_datax = %5d\r\n",gyro_datax);
		printf("gyro_datay = %5d\r\n",gyro_datay);
		printf("gyro_dataz = %5d\r\n",gyro_dataz);
		printf(" \r\n");
		
		BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
				BNO055_MAG_DATA_X_LSB_VALUEX_REG,
				&data[0], 1);
		delay_ms(100);
		BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
				BNO055_MAG_DATA_X_MSB_VALUEX_REG,
				&data[1], 1);
		printf("mag_x = 0x%x\r\n",0xffff&((data[1]<<8)|data[0]));
		clear_buff(data,8);
		delay_ms(100);
		BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
				BNO055_MAG_DATA_Y_LSB_VALUEY_REG,
				&data[0], 1);
		delay_ms(100);
		BNO055_I2C_bus_read(BNO055_I2C_ADDR2,
				BNO055_MAG_DATA_Y_MSB_VALUEY_REG,
				&data[1], 1);
		printf("mag_y = 0x%x\r\n",0xffff&((data[1]<<8)|data[0]));
		clear_buff(data,8);
#endif
		bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
		delay_ms(50);
		bno055_read_euler_hrp(&euler_hrp);

		x = euler_hrp.h;
		y = euler_hrp.r;
		z = euler_hrp.p;
		printf("euler_hrp.h = %5d\r\n",x);
		printf("euler_hrp.r = %5d\r\n",y);
		printf("euler_hrp.p = %5d\r\n",z);
		printf(" \r\n");
	//	delay_ms(3000);
		bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
		delay_ms(50);
		bno055_read_accel_xyz(&accel_xyz);
		x = accel_xyz.x;
		y = accel_xyz.y;
		z = accel_xyz.z;
		printf("accel_xyz.x = %5d\r\n",x);
		printf("accel_xyz.y = %5d\r\n",y);
		printf("accel_xyz.z = %5d\r\n",z);
		printf(" \r\n");
		delay_ms(3000);
		
		bno055_read_chip_id(&chip_id);
	
		printf("chip_id = %d\r\n",chip_id);
//		delay_ms(8000);
	}
}
#endif

