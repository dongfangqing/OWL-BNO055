#ifndef _RUN_TASK_H_
#define _RUN_TASK_H_

#include "stm32f10x.h" 


typedef enum
{
	MSG_0 = 0,
	MSG_1,
	MSG_2,
	MSG_3,
	MSG_4,
	MSG_5,
	MSG_6,
	MSG_7,
	MSG_8,
	MSG_9,

	MSG_100MS,
	MSG_200MS,
	MSG_HALF_SECOND,
	MSG_800MS,
	
	MSG_GET_ACCEL,
	MSG_GET_MAG,
	MSG_GET_GYRO,
	MSG_GET_EULER,
	MSG_GET_QUATERNION,
	MSG_GET_LINEAR_ACCEL,
	MSG_GET_GRAVITY,
	MSG_GET_TEMP,


	MSG_DATA_PACK,


	NO_MSG = 0xff
}_TASK_MSG;



/***********************************************************/


uint8_t Clear_Buff(u8 buf[],u8 len);

void Run_Start(void);


#endif


