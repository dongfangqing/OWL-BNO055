/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "i2croutines.h"
#include "i2cdev.h"


#if 1
#include "usart_driver.h"
#endif

#include "Data_Structure.h"
#include "Run_task.h"


/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

void RTCAlarm_IRQHandler(void)
{
#if 0
//	printf("RTCAlarm_IRQHandler\r\n");
    RTC_WaitForSynchro();  
	if(SET == RTC_GetFlagStatus(RTC_IT_ALR))
	{
		
		RTC_ClearFlag(RTC_IT_ALR);		////����жϱ�־λ
		
		if(EXTI_GetITStatus(EXTI_Line17))
		{
			EXTI_ClearITPendingBit(EXTI_Line17);     //����жϱ�־λ
		}	

		RTC_WaitForLastTask();  
		RTC_ClearITPendingBit(RTC_IT_ALR);  
		RTC_WaitForLastTask(); 
		
		Beep_Contrl(BEEP_ON);
	}
#endif
}

void RTC_IRQHandler(void)
{
	#if 0
//	printf("RTCAlarm_IRQHandler()\r\n");
	if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
	{
		/* Clear the RTC Second interrupt */
		RTC_ClearITPendingBit(RTC_IT_SEC);

		/* Enable time update */
		TimeDisplay = 1;

		/* Wait until last write operation on RTC registers has finished */
		RTC_WaitForLastTask();
	}
	
	if (RTC_GetITStatus(RTC_IT_ALR) != RESET)
	{
		/* Clear the RTC Second interrupt */
		RTC_ClearITPendingBit(RTC_IT_ALR);

		Beep_Contrl(BEEP_ON);

		/* Wait until last write operation on RTC registers has finished */
		RTC_WaitForLastTask();
	}
	#endif
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	
}

void EXTI0_IRQHandler(void)
{
	
}

void EXTI2_IRQHandler(void)
{
	
}

void EXTI4_IRQHandler(void)
{

}

//extern IIC_Type_Def IIC_Structure;
void EXTI9_5_IRQHandler(void)
{
}

void EXTI15_10_IRQHandler(void)
{
	
}




/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
void USART1_IRQHandler(void)
{
	
}

uint8_t ch;
uint8_t Recv_Count = 0;
uint16_t Recv_flag = 0;

void USART3_IRQHandler(void)
{
#if 0
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit (USART3, USART_IT_RXNE);
		usart3_putc(USART3->DR);
	}
#else
#ifdef USART3_ENABLE
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit (USART3, USART_IT_RXNE);
		
//		*(Usart3_RecvStat.Recv_end) = USART_ReceiveData(USART3);
		*(Usart3_RecvStat.Recv_end) = USART3->DR;
		usart1_putc(*(Usart3_RecvStat.Recv_end));
		
		Usart3_RecvStat.Recv_end++;
		Usart3_RecvStat.Recvcount++;
		
		if(USART3_BUFF <= Usart3_RecvStat.Recvcount)
		{
			Usart3_RecvStat.Recvcount = 0;
			Usart3_RecvStat.Recv_end = &Usart3_buff[0];
		}
		Recv_Count++;
		if(((u8)Usart3_buff[0] == 0xff)&&((u8)Usart3_buff[1] == 0xff))
		{
			if(Recv_Count == 4)
			{
				Recv_flag = 0xffff&((Usart3_buff[2]<<8)|Usart3_buff[3]);
			}

			if(Recv_Count == (Recv_flag+4))
			{
				put_msg_Fifo(MSG_DATA_PACK);
			}
		}

		
//	  	printf( "%c", Usart3_buff[Usart2_RecvStat.Recvcount-1]);    //�����ܵ�������ֱ�ӷ��ش�ӡ
//		usart3_putc(Usart3_buff[Usart2_RecvStat.Recvcount-1]);
		
		
	} 
#endif
#endif
}

void TIM2_IRQHandler(void)
{
	
}


void TIM3_IRQHandler(void)
{	
	
}


void SPI1_IRQHandler(void)
{
	
}

void I2C1_EV_IRQHandler(void)
{
	i2cInterruptHandlerI2c1();
}

void I2C1_ER_IRQHandler(void)
{
	i2cErrorInterruptHandlerI2c1();
}


void DMA1_Channel4_IRQHandler(void)
{
	i2cDmaInterruptHandlerI2c2();
}

void DMA1_Channel5_IRQHandler(void)
{
	i2cDmaInterruptHandlerI2c2();
}

void DMA1_Channel6_IRQHandler(void)
{
#if 0
	i2cDmaInterruptHandlerI2c1();
#endif
}

void DMA1_Channel7_IRQHandler(void)
{
#if 0
	i2cDmaInterruptHandlerI2c1();
#endif
}


/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
