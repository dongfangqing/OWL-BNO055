/*********************************SW-IOT32*********************************                                      
 
	                         \\\|///
                       \\  - -  //
                        (  @ @  )
+---------------------oOOo-(_)-oOOo-------------------------+
|                                                           |
|                             Oooo                          |
+-----------------------oooO--(   )-------------------------+
                       (   )   ) /
                        \ (   (_/
                         \_)           
***************************************************************************/

/*
	Ӧ��˵����
	�ڷ���I2C�豸ǰ�����ȵ��� i2c_CheckDevice() ���I2C�豸�Ƿ��������ú���������GPIO

*/

#include "stm32f10x.h"
#include "i2c_gpio.h"
#include "usart_driver.h"
#include "SysTick.h"

#if 1


//#define GPIO_PORT_I2C	GPIOB			/* GPIO�˿� */
//#define RCC_I2C_PORT 	RCC_APB2Periph_GPIOB		/* GPIO�˿�ʱ�� */
//#define I2C_SCL_PIN		GPIO_Pin_6			/* ���ӵ�SCLʱ���ߵ�GPIO */
//#define I2C_SDA_PIN		GPIO_Pin_7			/* ���ӵ�SDA�����ߵ�GPIO */


#if 1
#define GPIO_PORT_I2C	GPIOB			/* GPIO�˿� */
#define RCC_I2C_PORT 	RCC_APB2Periph_GPIOB		/* GPIO�˿�ʱ�� */
#define I2C_SCL_PIN		GPIO_Pin_6			/* ���ӵ�SCLʱ���ߵ�GPIO */
#define I2C_SDA_PIN		GPIO_Pin_7			/* ���ӵ�SDA�����ߵ�GPIO */
#else
#define GPIO_PORT_I2C	GPIOA			/* GPIO�˿� */
#define RCC_I2C_PORT 	RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define I2C_SCL_PIN		GPIO_Pin_11			/* ���ӵ�SCLʱ���ߵ�GPIO */
#define I2C_SDA_PIN		GPIO_Pin_12			/* ���ӵ�SDA�����ߵ�GPIO */
#endif


#if 0	/* �������룺 1 ѡ��GPIO�Ŀ⺯��ʵ��IO��д */
	#define I2C_SCL_1()  GPIO_SetBits(GPIO_PORT_I2C, I2C_SCL_PIN)		/* SCL = 1 */
	#define I2C_SCL_0()  GPIO_ResetBits(GPIO_PORT_I2C, I2C_SCL_PIN)		/* SCL = 0 */
	
	#define I2C_SDA_1()  GPIO_SetBits(GPIO_PORT_I2C, I2C_SDA_PIN)		/* SDA = 1 */
	#define I2C_SDA_0()  GPIO_ResetBits(GPIO_PORT_I2C, I2C_SDA_PIN)		/* SDA = 0 */
	
	#define I2C_SDA_READ()  GPIO_ReadInputDataBit(GPIO_PORT_I2C, I2C_SDA_PIN)	/* ��SDA����״̬ */
#else	/* �����֧ѡ��ֱ�ӼĴ�������ʵ��IO��д */
    /*��ע�⣺����д������IAR��߼����Ż�ʱ���ᱻ�����������Ż� */
	#define I2C_SCL_1()  GPIO_PORT_I2C->BSRR = I2C_SCL_PIN				/* SCL = 1 */
	#define I2C_SCL_0()  GPIO_PORT_I2C->BRR = I2C_SCL_PIN				/* SCL = 0 */
	
	#define I2C_SDA_1()  GPIO_PORT_I2C->BSRR = I2C_SDA_PIN				/* SDA = 1 */
	#define I2C_SDA_0()  GPIO_PORT_I2C->BRR = I2C_SDA_PIN				/* SDA = 0 */
	
	#define I2C_SDA_READ()  ((GPIO_PORT_I2C->IDR & I2C_SDA_PIN) != 0)	/* ��SDA����״̬ */
#endif

void I2C_GPIOInitConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_I2C_PORT,ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = I2C_SCL_PIN | I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);

	GPIO_SetBits(GPIO_PORT_I2C, I2C_SCL_PIN | I2C_SDA_PIN);
}

static void SDA_OUT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);

	GPIO_SetBits(GPIO_PORT_I2C,I2C_SDA_PIN);
}

static void SDA_IN(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);

	GPIO_SetBits(GPIO_PORT_I2C,I2C_SDA_PIN);
}
/**************************************
**************************************/
void I2C_Start()
{
	SDA_OUT();
    I2C_SDA_1();
    I2C_SCL_1();       
    delay_us(8);     
    I2C_SDA_0(); 
    delay_us(8);   
    I2C_SCL_0();  
}

/**************************************
**************************************/
void I2C_Stop()
{
	SDA_OUT();
	I2C_SDA_0();
	I2C_SCL_1();  
	delay_us(8);
    I2C_SDA_1();
    delay_us(8);
}

/**************************************
**************************************/
void I2C_SendACK(u8 ack)
{
	SDA_OUT();
	I2C_SCL_0();
	delay_us(8);
	if(ack)
		I2C_SDA_1();
	else I2C_SDA_0();
	I2C_SCL_1(); 
	delay_us(8);
	I2C_SCL_0();
	delay_us(8);
}

/**************************************
**************************************/
u8 I2C_RecvACK(void)
{
	u8 ucErrTime=0;

 	SDA_IN();
	I2C_SDA_1();
	delay_us(8);	   
	I2C_SCL_1();
	delay_us(8);
		 
	while(I2C_SDA_READ())
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			I2C_Stop();
			return 1;
		}
	}
	I2C_SCL_0();
	return 0;  
}

/**************************************
**************************************/
void I2C_SendByte(u8 dat)
{
	u8 t; 
	SDA_OUT(); 	    
    I2C_SCL_0();
    for(t=0;t<8;t++)
    {              
//        SDA=(dat&0x80)>>7;
		if(dat&0x80)
			I2C_SDA_1();
		else I2C_SDA_0();
		dat<<=1; 	  
		delay_us(5);
		I2C_SCL_1(); 
		delay_us(5); 
		I2C_SCL_0();
		delay_us(5);
    }	
//    I2C_RecvACK();
}

/**************************************
**************************************/	

u8 I2C_RecvByte(void)
{
	int i = 0;
	u8 byte = 0;
	SDA_IN();
	for(i = 0;i < 8;i++)
	{
		delay_us(12);
		I2C_SCL_1();
		delay_us(12);
		byte <<= 1;
		if(I2C_SDA_READ())
		{
			byte |= 0x01;
		}
		delay_us(12);
		I2C_SCL_0();
//		delay_us(2);
	}
	return byte;
}


/****************************************************************************
*	�� �� ��: i2c_CheckDevice
*	����˵��: ���I2C�����豸��CPU�����豸��ַ��Ȼ���ȡ�豸Ӧ�����жϸ��豸�Ƿ����
*	��    �Σ�_Address���豸��I2C���ߵ�ַ
*	�� �� ֵ: ����ֵ 0 ��ʾ��ȷ�� ����1��ʾδ̽�⵽
****************************************************************************/
uint8_t I2C_CheckDevice(uint8_t _Address)
{
	uint8_t ucAck;

	I2C_Start();		/* ���������ź� */

	/* �����豸��ַ+��д����bit��0 = w�� 1 = r) bit7 �ȴ� */
	I2C_SendByte(_Address<<1 | I2C_WR);
	ucAck = I2C_RecvACK();	/* ����豸��ACKӦ�� */

	I2C_Stop();			/* ����ֹͣ�ź� */

	return ucAck;
}

#else

#if 0
#define GPIO_PORT_I2C	GPIOB			/* GPIO�˿� */
#define RCC_I2C_PORT 	RCC_APB2Periph_GPIOB		/* GPIO�˿�ʱ�� */
#define I2C_SCL_PIN		GPIO_Pin_6			/* ���ӵ�SCLʱ���ߵ�GPIO */
#define I2C_SDA_PIN		GPIO_Pin_7			/* ���ӵ�SDA�����ߵ�GPIO */
#else
#define GPIO_PORT_I2C	GPIOA			/* GPIO�˿� */
#define RCC_I2C_PORT 	RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define I2C_SCL_PIN		GPIO_Pin_11			/* ���ӵ�SCLʱ���ߵ�GPIO */
#define I2C_SDA_PIN		GPIO_Pin_12			/* ���ӵ�SDA�����ߵ�GPIO */
#endif


#if 0	/* �������룺 1 ѡ��GPIO�Ŀ⺯��ʵ��IO��д */
	#define I2C_SCL_1()  GPIO_SetBits(GPIO_PORT_I2C, I2C_SCL_PIN)		/* SCL = 1 */
	#define I2C_SCL_0()  GPIO_ResetBits(GPIO_PORT_I2C, I2C_SCL_PIN)		/* SCL = 0 */
	
	#define I2C_SDA_1()  GPIO_SetBits(GPIO_PORT_I2C, I2C_SDA_PIN)		/* SDA = 1 */
	#define I2C_SDA_0()  GPIO_ResetBits(GPIO_PORT_I2C, I2C_SDA_PIN)		/* SDA = 0 */
	
	#define I2C_SDA_READ()  GPIO_ReadInputDataBit(GPIO_PORT_I2C, I2C_SDA_PIN)	/* ��SDA����״̬ */
#else	/* �����֧ѡ��ֱ�ӼĴ�������ʵ��IO��д */
    /*��ע�⣺����д������IAR��߼����Ż�ʱ���ᱻ�����������Ż� */
	#define I2C_SCL_1()  GPIO_PORT_I2C->BSRR = I2C_SCL_PIN				/* SCL = 1 */
	#define I2C_SCL_0()  GPIO_PORT_I2C->BRR = I2C_SCL_PIN				/* SCL = 0 */
	
	#define I2C_SDA_1()  GPIO_PORT_I2C->BSRR = I2C_SDA_PIN				/* SDA = 1 */
	#define I2C_SDA_0()  GPIO_PORT_I2C->BRR = I2C_SDA_PIN				/* SDA = 0 */
	
	#define I2C_SDA_READ()  ((GPIO_PORT_I2C->IDR & I2C_SDA_PIN) != 0)	/* ��SDA����״̬ */
#endif

void I2C_GPIOInitConfig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_I2C_PORT,ENABLE); 
	
	GPIO_InitStructure.GPIO_Pin = I2C_SCL_PIN | I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);

	GPIO_SetBits(GPIO_PORT_I2C, I2C_SCL_PIN | I2C_SDA_PIN);
}

static void SDA_OUT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);

	GPIO_SetBits(GPIO_PORT_I2C,I2C_SDA_PIN);
}

static void SDA_IN(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = I2C_SDA_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIO_PORT_I2C, &GPIO_InitStructure);
}
/**************************************
**************************************/
void I2C_Start()
{
	SDA_OUT();
	I2C_SDA_1();
	I2C_SCL_1();  
	delay_us(4);
 	I2C_SDA_0(); 
	delay_us(4);
	I2C_SCL_0();
}

/**************************************
**************************************/
void I2C_Stop()
{
	SDA_OUT();
	I2C_SDA_0();
	I2C_SCL_1();  
	delay_us(4);
	I2C_SDA_1();
	delay_us(4);
}

/**************************************
**************************************/
void I2C_SendACK(u8 ack)
{
	SDA_OUT();
	I2C_SCL_0();
	delay_us(2);
	if(ack)
		I2C_SDA_1();
	else I2C_SDA_0();
	I2C_SCL_1(); 
	delay_us(2);
	I2C_SCL_0();
	delay_us(2);
}

/**************************************
**************************************/
u8 I2C_RecvACK(void)
{
	u8 ucErrTime=0;

 	SDA_IN();
	I2C_SDA_1();
	delay_us(1);	   
	I2C_SCL_1();
	delay_us(1);
		 
	while(I2C_SDA_READ())
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			I2C_Stop();
			return 1;
		}
	}
	I2C_SCL_0();
	return 0;  
}


/**************************************
**************************************/
void I2C_SendByte(u8 dat)
{
	u8 t; 
	SDA_OUT(); 	    
	I2C_SCL_0();
	for(t=0;t<8;t++)
	{
		if(dat&0x80)
			I2C_SDA_1();
		else 
			I2C_SDA_0();
		dat<<=1; 	  
		delay_us(2);
		I2C_SCL_1();
		delay_us(2); 
		I2C_SCL_0();
		delay_us(2);
	}	
}

/**************************************
**************************************/	
#if 0
u8 I2C_RecvByte(void)
{
	int i = 0;
	u8 byte = 0;
	SDA_IN();
	for(i = 0;i < 8;i++)
	{
		delay_us(5);
		I2C_SCL_1();
		delay_us(5);
		byte <<= 1;
		if(I2C_SDA_READ())
		{
			byte |= 0x01;
		}
		I2C_SCL_0();
		delay_us(5);
	}
	return byte;
}
#else
u8 I2C_RecvByte(unsigned char ack)
{
	unsigned char i,receive=0;
	SDA_IN();
	for(i=0;i<8;i++ )
	{
		I2C_SCL_0();
		delay_us(2);
		I2C_SCL_1();
		receive<<=1;
		if(I2C_SDA_READ())
			receive++;   
		delay_us(1); 
	}					 
	if (!ack)
		I2C_SendACK(1);
	else
		I2C_SendACK(0);
	return receive;
}
#endif

/****************************************************************************
*	�� �� ��: i2c_CheckDevice
*	����˵��: ���I2C�����豸��CPU�����豸��ַ��Ȼ���ȡ�豸Ӧ�����жϸ��豸�Ƿ����
*	��    �Σ�_Address���豸��I2C���ߵ�ַ
*	�� �� ֵ: ����ֵ 0 ��ʾ��ȷ�� ����1��ʾδ̽�⵽
****************************************************************************/
uint8_t I2C_CheckDevice(uint8_t _Address)
{
	uint8_t ucAck;

	I2C_Start();		/* ���������ź� */

	/* �����豸��ַ+��д����bit��0 = w�� 1 = r) bit7 �ȴ� */
	I2C_SendByte(_Address | I2C_WR);
	ucAck = I2C_RecvACK();	/* ����豸��ACKӦ�� */

	I2C_Stop();			/* ����ֹͣ�ź� */

	return ucAck;
}



void WriteData(u8 DevAddr,u8 Reg_Addr,u8 Dat)
{
	I2C_Start();
	I2C_SendByte(DevAddr << 1| I2C_WR);
	I2C_RecvACK();
	I2C_SendByte(Reg_Addr);
	I2C_RecvACK();
	I2C_SendByte(Dat);
	I2C_RecvACK();
	I2C_Stop();
	delay_ms(10);
}


void ReadData(u8 DevAddr,u8 Reg_Addr,u8 *Pbuf,u8 Num)
{
	u8 i;
	
	I2C_Start();
	I2C_SendByte(DevAddr << 1 | I2C_WR);
	I2C_RecvACK();
	I2C_SendByte(Reg_Addr);
	I2C_RecvACK();
	I2C_Start();
	I2C_SendByte(DevAddr << 1 | I2C_RD);
	I2C_RecvACK();
	for(i = 0;i < (Num - 1);i ++)
	{
		Pbuf[i] = I2C_RecvByte(1);
	}
	Pbuf[i] = I2C_RecvByte(0);
	I2C_Stop();
	delay_ms(5);
}



#endif
