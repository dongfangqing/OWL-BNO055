#ifndef _I2C_GPIO_H_
#define _I2C_GPIO_H_

#include "stm32f10x.h" 
#include <inttypes.h>

#define I2C_WR	0		/* д����bit */
#define I2C_RD	1		/* ������bit */


#if 1
void I2C_GPIOInitConfig(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_SendACK(u8 ack);
u8 I2C_RecvACK(void);
void I2C_SendByte(u8 dat);
u8 I2C_RecvByte(void);

uint8_t I2C_CheckDevice(uint8_t _Address);

#else
void I2C_GPIOInitConfig(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_SendACK(u8 ack);
u8 I2C_RecvACK(void);
void I2C_SendByte(u8 dat);

uint8_t I2C_CheckDevice(uint8_t _Address);

u8 I2C_RecvByte(unsigned char ack);


void WriteData(u8 DevAddr,u8 Reg_Addr,u8 Dat);
void ReadData(u8 DevAddr,u8 Reg_Addr,u8 *Pbuf,u8 Num);

#endif

#endif
