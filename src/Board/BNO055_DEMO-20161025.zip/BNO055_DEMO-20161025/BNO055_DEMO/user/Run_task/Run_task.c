#include "Run_task.h"
#include "Data_Structure.h"
#include "data_pack.h"
#include "usart_driver.h"
#include "bno055.h"
#include "bno055_sonser.h"
#include "SysTick.h"


static void DevCmd_Msg(uint8_t cmd)
{
	switch(cmd)
	{
		case DEV_ACCEL:
			put_msg_Fifo(MSG_GET_ACCEL);
			break;
		case DEV_GYRO:
			put_msg_Fifo(MSG_GET_GYRO);
			break;
		case DEV_MAG:
			put_msg_Fifo(MSG_GET_MAG);
			break;
		case DEV_EULER:
			put_msg_Fifo(MSG_GET_EULER);
			break;
		case DEV_QUATERNION:
			put_msg_Fifo(MSG_GET_QUATERNION);
			break;
		case DEV_LINEAR_ACCEL:
			put_msg_Fifo(MSG_GET_LINEAR_ACCEL);
			break;
		case DEV_GRAVITY:
			put_msg_Fifo(MSG_GET_GRAVITY);
			break;
		case DEV_TEMP:
			put_msg_Fifo(MSG_GET_TEMP);
			break;
	}
}

uint8_t Clear_Buff(u8 buf[],u8 len)
{
	uint8_t i = 0;

	for(i = 0;i < len;i++)
	{
		buf[i] = 0;
	}

	return i;
}

void Run_Task(void)
{
	uint8_t msg = NO_MSG;
	uint8_t Tx_Buff[30];
	s16 w,  x,  y,  z;
	float temp;

	/* variable used to read the accel xyz data */
	struct bno055_accel_t accel_xyz;
	/* structure used to read the mag xyz data */
	struct bno055_mag_t mag_xyz;
	 /* structure used to read the gyro xyz data */
	struct bno055_gyro_t gyro_xyz;
	/* structure used to read the euler hrp data */
	struct bno055_euler_t euler_hrp;
	/* structure used to read the quaternion wxyz data */
	struct bno055_quaternion_t quaternion_wxyz;
	/* structure used to read the linear accel xyz data */
	struct bno055_linear_accel_t linear_acce_xyz;
	/* structure used to read the gravity xyz data */
	struct bno055_gravity_t gravity_xyz;

	
	while(1)
	{
		msg = get_msg_Fifo();

		switch(msg)
		{
			case MSG_GET_ACCEL:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
				delay_ms(100);
				bno055_read_accel_xyz(&accel_xyz);
				x = accel_xyz.x;
				y = accel_xyz.y;
				z = accel_xyz.z;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_ACCEL, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_MAG:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
				delay_ms(100);
				bno055_read_mag_xyz(&mag_xyz);
				x = mag_xyz.x;
				y = mag_xyz.y;
				z = mag_xyz.z;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_MAG, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_GYRO:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
				delay_ms(100);
				bno055_read_gyro_xyz(&gyro_xyz);
				x = gyro_xyz.x;
				y = gyro_xyz.y;
				z = gyro_xyz.z;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_GYRO, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_EULER:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
				delay_ms(100);
				bno055_read_euler_hrp(&euler_hrp);

				x = euler_hrp.h;
				y = euler_hrp.r;
				z = euler_hrp.p;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_EULER, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_QUATERNION:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
				delay_ms(100);
				bno055_read_quaternion_wxyz(&quaternion_wxyz);
				w = quaternion_wxyz.w;
				x = quaternion_wxyz.x;
				y = quaternion_wxyz.y;
				z = quaternion_wxyz.z;
				
				Pack_IntegerData(Tx_Buff, 16-4, DEV_QUATERNION, DevSeqByte, w, x, y, z);
				usart3_putstr(Tx_Buff,16);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_LINEAR_ACCEL:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
				delay_ms(100);
				bno055_read_linear_accel_xyz(&linear_acce_xyz);
				x = linear_acce_xyz.x;
				y = linear_acce_xyz.y;
				z = linear_acce_xyz.z;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_LINEAR_ACCEL, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_GRAVITY:
				bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
				delay_ms(100);
				bno055_read_gravity_xyz(&gravity_xyz);
				x = gravity_xyz.x;
				y = gravity_xyz.y;
				z = gravity_xyz.z;
				
				Pack_IntegerData(Tx_Buff, 14-4, DEV_GRAVITY, DevSeqByte, 0, x, y, z);
				usart3_putstr(Tx_Buff,14);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_GET_TEMP:
				bno055_convert_float_temp_celsius(&temp);

				
				Pack_IntegerData_Temp(Tx_Buff,10-4,DevSeqByte, temp);
				usart3_putstr(Tx_Buff,10);
				Clear_Buff(Tx_Buff,30);
				break;
			case MSG_DATA_PACK:
				DevCmd_Msg(Untie_DataPack((uint8_t*)Usart3_RecvStat.Recv_start));
				Clear_USART_Buff(USART3_BUF);
				break;
			default:
				break;
		}
	}
}



void Run_Start(void)
{
	SeqQueue_Init();
	Clear_msg_Fifo();

	bno055_Setup();


	Run_Task();
}







