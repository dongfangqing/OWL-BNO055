/*********************************SW-IOT32*********************************                                      
 
	                         \\\|///
                       \\  - -  //
                        (  @ @  )
+---------------------oOOo-(_)-oOOo-------------------------+
|                                                           |
|                             Oooo                          |
+-----------------------oooO--(   )-------------------------+
                       (   )   ) /
                        \ (   (_/
                         \_)           
***************************************************************************/

#include "stm32f10x.h" 
#include "sys_rcc.h"
#include "SysTick.h"
#include "led_driver.h" 
#include "usart_driver.h" 
#include "bno055.h"
#include "i2c_gpio.h"
#include "bno055_sonser.h"
#include "i2croutines.h"
#include "i2cdev.h"
#include "Run_task.h"
#include "HF_LPT200.h"
#include "Bluetooth.h"
#include "OLED_Device.h"
#include "spi_driver.h"
#include "adc_driver.h"
#include "ST_string.h"


extern s32 bno055_data_readout_template(void);
extern uint8_t BNO055_CheckOk(void);
extern s8 BNO055_I2C_bus_write(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);
extern s8 BNO055_I2C_bus_read(u8 dev_addr, u8 reg_addr, u8 *reg_data, u8 cnt);

extern void WIFI_HF_LPT200_Init(void);
extern struct bno055_t bno055;
int main(void)
{
//	u8 chip_id = 0;
	int i = 0;
	int ble_key_flag = 0;
	int wifi_key_flag = 0;
	struct bno055_euler_t euler_hrp;
	s16 Yaw,Roll,Pitch;
	u8 data[8];
	
	RCC_Configuration();
	SysTick_init(72);
	USART_InitConfig();
	SPI_InitConfig();
	LCD_Init();
	ADC1_Init();
	
//	printf("hello main!!\r\n");
	LED_GPIO_Config();		
	I2C_GPIOInitConfig();
	i2cdevInit(I2C1);
	bno055_Setup();	
	
	WIFI_HF_LPT200_RestoreFactory();	
	WIFI_HF_LPT200_Init();	
//	WIFI_HF_LPT200_Set_TCPServer_Mode();
//	WIFI_HF_LPT200_Set_TCPClient_Mode("8899,10.10.100.254");	
	WIFI_HF_LPT200_Leave_ATMode();
	
//	delay_ms(1000);	
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
//	delay_ms(1000);
	
	
	if(WIFI_HF_LPT200_Check_Start())
		printf("Wifi Startup Filed!!!\r\n");
	else
		printf("Wifi Startup OK!!!\r\n");
	printf("hello ccc\r\n");
	
	Bluetooth_RF_BM_S02_Port_GPIO_Init();
	delay_ms(100);
	Bluetooth_RF_BM_S02_Connect_Mode();
	//while(!Bluetooth_RF_BM_S02_Check_Connect_State());
	delay_ms(100);
	Bluetooth_RF_BM_S02_change_Connect_time();
	Bluetooth_RF_BM_S02_change_name();
	//Bluetooth_RF_BM_S02_change_BPS();
			
	bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
	delay_ms(100);
	

			
	while(1)
	{		
		bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
		delay_ms(100);
		
		bno055_read_euler_hrp(&euler_hrp);
		Yaw = euler_hrp.h;
		Roll= euler_hrp.r;
		Pitch = euler_hrp.p;
		
		Yaw = Yaw/15;
		Roll = Roll/15;
		Pitch = Pitch/15;
		//printf("Roll=%hd	Pitch=%hd	YAW=%hd\r\n",Roll,Pitch,Yaw);		
		
		data[0] = (Roll>>8)&0xff;
		data[1] = Roll&0xff;
		data[2] = (Pitch>>8)&0xff;
		data[3] = Pitch&0xff;
		data[4] = (Yaw>>8)&0xff;
		data[5] = Yaw&0xff;
			
		//wifi
		for(i=0;i<6;i++)
		{
			usart3_putc(data[i]);
			//printf("%c",data_to_Bluetooth[i]);
		}			
		
		//Bluetooth
		BRTS_State(GPIO_OUT_LOW);
		delay_ms(10);
		for(i=0;i<6;i++)
		{
			usart1_putc(data[i]);
		}
		delay_ms(5);
		BRTS_State(GPIO_OUT_HIGH);
		delay_ms(40);
	}
}


	


