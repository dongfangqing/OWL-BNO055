#ifndef _IR_SENSOR_H_
#define _IR_SENSOR_H_

#include "stm32f10x.h"





void IR_GPIOConfig(void);
uint8_t Get_IrDensor_status(void);




#endif

