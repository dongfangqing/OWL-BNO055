
#ifndef __BLUETOOTH_H__
#define __BLUETOOTH_H__


#include "stm32f10x.h" 
#include "sys_rcc.h"
#include "SysTick.h"

/***************************************************************/
#define GPIO_OUT_HIGH	1
#define GPIO_OUT_LOW	0


#define BM_S02_ReSet(a)		if (a)	\
							GPIO_SetBits(GPIOB,GPIO_Pin_13);\
							else		\
							GPIO_ResetBits(GPIOB,GPIO_Pin_13)

#define BM_S02_EN(a)		if (a)	\
							GPIO_SetBits(GPIOB,GPIO_Pin_12);\
							else		\
							GPIO_ResetBits(GPIOB,GPIO_Pin_12)
						
#define BM_S02_Check_Connect_State	GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)

#define BRTS_State(a)		if (a)	\
							GPIO_SetBits(GPIOA,GPIO_Pin_12);\
							else		\
							GPIO_ResetBits(GPIOA,GPIO_Pin_12)
							
#define BCTS_State					GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11)							

#define BM_S02_RestoreFactory(a)	if (a)	\
									GPIO_SetBits(GPIOB,GPIO_Pin_15);\
									else		\
									GPIO_ResetBits(GPIOB,GPIO_Pin_15)	


void Bluetooth_RF_BM_S02_Port_GPIO_Init(void);
void Bluetooth_RF_BM_S02_change_name(void);
void Bluetooth_RF_BM_S02_change_Connect_time(void);
void Bluetooth_RF_BM_S02_change_BPS(void);
void Bluetooth_RF_BM_S02_Connect_Mode(void);
void Bluetooth_RF_BM_S02_Sleep_Mode(void);
void Bluetooth_RF_BM_S02_ReSet(void);
u8 Bluetooth_RF_BM_S02_Check_Connect_State(void);
void Bluetooth_RF_BM_S02_RestoreFactory(int i);


#endif

									