#ifndef _DATA_PACK_H_
#define _DATA_PACK_H_

#include "stm32f10x.h" 


#if 0
typedef enum
{
	0x10,	//Accelerometer
	0x11,	//Gyroscope
	0x12,	//Magnetometer
	0x13,	//euler
	0x14,	//quaternion
	0x15,	//linear_accel
	0x16,	//gravity
	0x17,	//temperature
}DEV_TYPE;

#else

typedef enum
{
	DEV_ACCEL = 0X10,
	DEV_MAG,
	DEV_GYRO ,
	DEV_EULER,
	DEV_QUATERNION,
	DEV_LINEAR_ACCEL,
	DEV_GRAVITY,
	DEV_TEMP,
}DEV_TYPE;

#endif



extern uint8_t DevSeqByte;


uint8_t Pack_IntegerData(u8 buff[],uint16_t lenth,uint8_t cmd,uint8_t seq,
			uint16_t w,uint16_t x,uint16_t y,uint16_t z);
uint8_t Pack_IntegerData_Temp(u8 buff[],uint16_t lenth,uint8_t seq,float temp);
uint8_t Untie_DataPack(uint8_t buff[]);

#endif



