/*********************************SW-IOT32*********************************                                      
 
	                         \\\|///
                       \\  - -  //
                        (  @ @  )
+---------------------oOOo-(_)-oOOo-------------------------+
|                                                           |
|                             Oooo                          |
+-----------------------oooO--(   )-------------------------+
                       (   )   ) /
                        \ (   (_/
                         \_)           
***************************************************************************/

#include "stm32f10x.h" 
#include "sys_rcc.h"
#include "SysTick.h"
#include "led_driver.h" 
#include "usart_driver.h" 
#include "bno055.h"
#include "i2c_gpio.h"
#include "bno055_sonser.h"
#include "i2croutines.h"
#include "i2cdev.h"
#include "Bluetooth.h"
#include "TIM_driver.h"
#include "STM32_ChipID.h"
#include "ST_string.h"
#include <stdlib.h>
#include <math.h>

extern int time_out_flag;

#define M_PI 3

struct angle_t {
	s16 roll;
	s16 pitch;
	s16 yaw;
};

static float invSqrt(float x) 
{
	float halfx = 0.5f * x;
	float y = x;
	long i = *(long*)&y;
	i = 0x5f3759df - (i>>1);
	y = *(float*)&i;
	y = y * (1.5f - (halfx * y * y));
	return y;
}

void quaternion2euler(struct angle_t *angle,int w,int x,int y,int z)
{
	int norm;
	norm = invSqrt(w*w + x*x + y*y +z*z);
	w *= norm;
	x *= norm;
	y *= norm;
	z *= norm;
	
	angle->roll = (atan2(2.0*(w*x + y*z), 1 - 2.0*(x*x + y*y)));
	// we let safe_asin() handle the singularities near 90/-90 in pitch
	angle->pitch = asin(2.0*(w*y - z*x));
	angle->yaw = -atan2(2.0*(w*z + x*y), 1 - 2.0*(y*y + z*z));
}

int main(void)
{
	//shark
	//Protocol Strings�ַ���Э��
	char sidReq[] = "board_get_sid()";   //SID RequestSidҪ��
	char sidResp[] = "board_sid(A0)";    //SID ResponseSID��Ӧ
	char startStr[] = "bsx_get_data(-1,4)";  //Start Streaming��ʼ��
	char stopStr[] = "bsx_get_data(0,4)";  //Stop Streaming������
	int streamData = 0;                    //Flag to know whether data has to be streamed��־����֪���Ƿ������ѱ�����
	int readData = 1;                       //Flag to know whether the next read is required��־����֪���Ƿ���Ҫ�Ķ���һ���Ķ�
	int index = 0;
	const int maxPktSize = 63;                   //Maximum packet size������ݰ���С
	uint16_t streamPkt[maxPktSize] = {0};            //Array to store the packet that has to be streamed�������洢Ҫ����������ݰ�
	uint16_t w,  x,  y,  z;
	u8 checkSum = 0;                           //Variables to store the checksum�����洢��У���
	unsigned char accel_calib_status = 0;
	unsigned char mag_calib_status = 0;
	unsigned char gyro_calib_status = 0;
	
	//ANO
	char data_to_send[32]={0};
	
	//Bluetooth
	char data_to_Bluetooth[6] = {0};
	
	s16 Roll,  Pitch,  Yaw;
	int i;
	int sum = 0;

	
	struct bno055_euler_t euler_hrp;
	struct bno055_quaternion_t quaternion_wxyz;
	struct angle_t angle;
	
	RCC_Configuration();
	SysTick_init(72);
	USART_InitConfig();
	TIM_InitConfig();
	printf("hello main!!\r\n");
	LED_GPIO_Config();
	I2C_GPIOInitConfig();
	i2cdevInit(I2C1);
	bno055_Setup();
	
	
	bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
	delay_ms(100);
	
	
//	printf("hello main!!\r\n");
	//printf("hello ccc\r\n");

	
	PWM_Channel1_Out(10);
	PWM_Channel2_Out(130);
	PWM_Channel3_Out(10);
	
	Bluetooth_RF_BM_S02_Port_GPIO_Init();
	delay_ms(100);
	Bluetooth_RF_BM_S02_Connect_Mode();
	while(!Bluetooth_RF_BM_S02_Check_Connect_State());
	delay_ms(100);
	Bluetooth_RF_BM_S02_change_Connect_time();
	Bluetooth_RF_BM_S02_change_name();
	//Bluetooth_RF_BM_S02_change_BPS();
	
	while(1)
	{
		bno055_set_operation_mode(BNO055_OPERATION_MODE_NDOF);
		delay_ms(100);
		bno055_read_euler_hrp(&euler_hrp);
		Yaw = euler_hrp.h;
		Roll= euler_hrp.r;
		Pitch = euler_hrp.p;
		
		Yaw = Yaw/15;
		Roll = Roll/15;
		Pitch = Pitch/15;
		printf("Roll=%hd	Pitch=%hd	YAW=%hd\r\n",Roll,Pitch,Yaw);		
		
		data_to_Bluetooth[0] = (Roll>>8)&0xff;
		data_to_Bluetooth[1] = Roll&0xff;
		data_to_Bluetooth[2] = (Pitch>>8)&0xff;
		data_to_Bluetooth[3] = Pitch&0xff;
		data_to_Bluetooth[4] = (Yaw>>8)&0xff;
		data_to_Bluetooth[5] = Yaw&0xff;
				
		if(BCTS_State == 0)
		{
			while(BCTS_State == 0);
#ifdef USART3_DEBUG
			printf("%s\r\n",Usart1_buff);
			Clear_USART_Buff(USART1_BUF);
#endif			
			
		}
		BRTS_State(GPIO_OUT_LOW);
		delay_ms(10);
		//usart1_putstr("hello Bluetooth",st_strlen("hello Bluetooth"));
		for(i=0;i<6;i++)
		{
			usart1_putc(data_to_Bluetooth[i]);
			//printf("%c",data_to_Bluetooth[i]);
		}
		//printf("\r\n");
		st_memset(data_to_Bluetooth,0,6);
		delay_ms(5);
		BRTS_State(GPIO_OUT_HIGH);
		delay_ms(40);
	}
	
#if 0
	while(1)
	{
		bno055_read_euler_hrp(&euler_hrp);
		Yaw = euler_hrp.h;
		Roll= euler_hrp.r;
		Pitch = euler_hrp.p;
		
		data_to_send[0] = 0xAA;
		data_to_send[1] = 0xAA;
		data_to_send[2] = 0x01;
		data_to_send[3] = 0x0C;
		
		data_to_send[4] = (Roll>>8)&0xff;
		data_to_send[5] = Roll&0xff;
		data_to_send[6] = (Pitch>>8)&0xff;
		data_to_send[7] = Pitch&0xff;
		data_to_send[8] = (Yaw>>8)&0xff;
		data_to_send[9] = Yaw&0xff;
		
		data_to_send[10] = 0;
		data_to_send[11] = 0;
		data_to_send[12] = 0;
		data_to_send[13] = 0;
		data_to_send[14] = 0;
		data_to_send[15] = 0;
		
		for(i = 0; i < 16; i++)
		{
			sum += data_to_send[i];
		}
		data_to_send[16] = sum;
		
		if((time_out_flag%2) == 0)
		{
			//Print out the packet
			for (index = 0; index < 17; index++)
			{
				printf("%c",data_to_send[index]);
			}
	
		}
		
	}
#endif
	
#if 0
	//shark
	while(1)
	{
		if( st_strcmp((int8_t *)Usart1_buff,(int8_t *)sidReq) == 0)
		{
			Clear_USART_Buff(USART1_BUF);
			printf("%s",sidResp);
			streamData = 1;
			
		}
		else if(st_strcmp((int8_t *)Usart1_buff,(int8_t *)stopStr) == 0)
		{
			Clear_USART_Buff(USART1_BUF);
			streamData = 0;
		}
		else if(st_strcmp((int8_t *)Usart1_buff,(int8_t *)startStr) == 0)
		{			
			Clear_USART_Buff(USART1_BUF);
			streamData = 1;
		}
		
		if(readData)
		{
				bno055_read_quaternion_wxyz(&quaternion_wxyz);
				w = quaternion_wxyz.w;
				x = quaternion_wxyz.x;
				y = quaternion_wxyz.y;
				z = quaternion_wxyz.z;
			
				streamPkt[0] = 0x04;
				streamPkt[1] = 0x11;
				streamPkt[38] = (w>>8)&0xff;
				streamPkt[39] = w&0xff;
				streamPkt[40] = (x>>8)&0xff;
				streamPkt[41] = x&0xff;
				streamPkt[42] = (y>>8)&0xff;
				streamPkt[43] = y&0xff;
				streamPkt[44] = (z>>8)&0xff;
				streamPkt[45] = z&0xff;
				checkSum = streamPkt[38] + streamPkt[39] + streamPkt[40] + streamPkt[41] + streamPkt[42] + streamPkt[43] + streamPkt[44] + streamPkt[45];
				streamPkt[52] = (checkSum>>8)&0xff;
				streamPkt[53] = checkSum&0xff;
				
				streamPkt[58] = bno055_get_accel_calib_stat(&accel_calib_status);		
				streamPkt[59] = bno055_get_mag_calib_stat(&mag_calib_status);
				streamPkt[60] = bno055_get_gyro_calib_stat(&gyro_calib_status);
				
				readData = 0;
		}
		if (streamData)
		{
				if((time_out_flag%5) == 0)
				{
					//Print out the packet
					for (index = 0; index < maxPktSize; index++)
					{
						printf("%c",streamPkt[index]);
					}
					readData = 1;
				}
		}
		
	}
			
#endif
	
#if 0				
	while(1)
	{
		bno055_read_quaternion_wxyz(&quaternion_wxyz);
		printf("W=%d\r\n",quaternion_wxyz.w);
		printf("X=%d\r\n",quaternion_wxyz.w);
		printf("Y=%d\r\n",quaternion_wxyz.y);
		printf("Z=%d\r\n",quaternion_wxyz.z);
		printf("\r\n");
		printf("\r\n");
		delay_ms(1000);	
	}
#endif

#if 0				
while(1)
{
		bno055_read_euler_hrp(&euler_hrp);
		printf("Yaw=%d\r\n",euler_hrp.h);
		printf("Roll=%d\r\n",euler_hrp.r);
		printf("Pitch=%d\r\n",euler_hrp.p);
		printf("\r\n");
		printf("\r\n");
		delay_ms(1000);	
}
#endif
	
	
}

