#include "bno055_sonser.h"
#include "bno055.h"
#include "i2c_gpio.h"
#include "usart_driver.h" 
#include "SysTick.h"







extern struct bno055_t bno055;
void bno055_Setup(void)
{
//	s32 comres = BNO055_ERROR;
	u8 power_mode = BNO055_INIT_VALUE;

	
	I2C_routine();

//	comres = 
	bno055_init(&bno055);
/*	printf("comres = %d\r\n",comres);
	if(comres != BNO055_SUCCESS)
	{
		printf("bno055_init Filed!!\r\n");
	}*/

	
	power_mode = BNO055_POWER_MODE_NORMAL;
	/* set the power mode as NORMAL*/
//	comres = 
	bno055_set_power_mode(power_mode);
/*	if(comres != BNO055_SUCCESS)
	{
		printf("bno055_set_power_mode Filed!!\r\n");
	}*/
	delay_ms(100);
//	comres = 
	bno055_set_operation_mode(BNO055_OPERATION_MODE_AMG);
/*	if(comres != BNO055_SUCCESS)
	{
		printf("bno055_set_operation_mode Filed!!\r\n");
	}*/
	delay_ms(100);
}







